package com.web.adv.pages;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.xml.sax.SAXException;
import com.adv.common.Common;
import com.adv.common.ExcelManager;
import com.adv.helper.IConstants;
import com.relevantcodes.extentreports.*;

import jxl.read.biff.BiffException;
import jxl.write.WritableWorkbook;

public class WebTestCase{
	protected static WebDriver driver = null;
	private WritableWorkbook workbook;
	protected WebPageFactory pageFactory;
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String result_FolderNamePath = ".//Reports/";
	public static String result_FolderNamePathLocal = "/Reports/";
	public static String result_FolderName = null;
	public ExcelManager ex = new ExcelManager();
	protected String browserValue=null;
	protected String enviornment=null;
	protected ITestContext testContextValue;
	private com.adv.common.ExcelManager xls = new com.adv.common.ExcelManager(System.getProperty("user.dir")
			+ "\\data\\" + this.getClass().getSimpleName() + ".xlsx");
	String executionCoverageReport="ADVSummaryReport";

	public static int TSColPos;
	public static boolean SkipMethod=false;
	public static String WantToCleanAndRun=null; // this will impact on ADVSummaryReport excel file
	private String testClassName=null;

	public WebTestCase() {
		
	}
	@DataProvider(name = "inputdata")
	public Object[][] readExcelData(Method m) {
		Object[][] sheetData = null;

		sheetData = xls.getData1(m.getName(), "Test Data");
		return sheetData;
	}


	public void initilizeWebfactory(WebDriver driver)
	{
		pageFactory = new WebPageFactory(driver);
	}
	public WebDriver getDriver() {
		return driver;
	}
	//*****
	public static ExtentTest getTest() {
		return test;
	}
	/**
	 * @param test the test to set
	 */
	public static void setTest(ExtentTest test) {
		WebTestCase.test = test;
	}

	public void setDriver(WebDriver driver) {
		WebTestCase.driver = driver;
	}
	public WritableWorkbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(WritableWorkbook workbook) {
		this.workbook = workbook;
	}

	public WebPageFactory getPageFactory() {
		return pageFactory;
	}

	public void setPageFactory(WebPageFactory pageFactory) {
		this.pageFactory = pageFactory;
	}
	@BeforeSuite(alwaysRun = true)
	public void beforeSuite(ITestContext testContext) throws BiffException, IOException{
		WantToCleanAndRun=testContext.getCurrentXmlTest().getParameter("WantToCleanAndRun");
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  Before Suite  *************************",true);
		int ss_path=Common.generateRandomIntIntRange(0,100);
		try {
			File directory = new File(System.getProperty("user.dir") +"/"+IConstants.SCREENSHOTS_LOCATION );
			if (directory.exists()){
				FileUtils.cleanDirectory(new File(System.getProperty("user.dir") +"/"+IConstants.SCREENSHOTS_LOCATION ));
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		} 

		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		result_FolderName = result_FolderNamePath + date.substring(0, 10) + "/ADV_TEST_REPORT" + "_" + date;
		new File(result_FolderName).mkdirs();
		extent = new ExtentReports(createDir(result_FolderName)+"/ADVReport.html",true);
		Reporter.log("*********************************************************",true);

		String coverageSheet="SummaryReport";
		if(WantToCleanAndRun.contains("Yes")) {
			TSColPos= ex.cleanAndCreateTestScenarioDetails(executionCoverageReport, coverageSheet,0, 0,"",true);
		}else {
			TSColPos= ex.cleanAndCreateTestScenarioDetails(executionCoverageReport, coverageSheet,0, 0,"",false);
		}

	}
	public static String createDir(String directoryName){
		File directory = new File(directoryName);
		if (! directory.exists()){
			directory.mkdir();
		}else{
			Reporter.log("Directory already exists..."+directory,true);
		}
		return directoryName;
	}
	@SuppressWarnings("unused")
	@BeforeClass(alwaysRun=true)
	public void beforeClass() throws BiffException, IOException{
		System.out.println("****************************beforeClass ***********************");
		testClassName = this.getClass().getName();
		System.out.println("class name:: " + testClassName);

	}
	@SuppressWarnings("unused")
	@BeforeMethod(alwaysRun=true)
	public void beforeMethod(Method method) throws BiffException, IOException{
		System.out.println("****************************beforeMethod ***********************");
		String coverageSheet="SummaryReport";
		// get the row index of scenario in summary file, if availavle then return rownumber or make an entry on new scenario
		int rowPos= ex.getRowIndex(executionCoverageReport, coverageSheet, method.getName(),2);
		if(rowPos==0) {
			rowPos= ex.UpdateTestCaseScenarioExcel(executionCoverageReport, coverageSheet,testClassName,method.getName());
		}
		String WantToExecute= ex.readResultSummary(executionCoverageReport, coverageSheet, rowPos, 0);
		
		String ExecutionResult= ex.readResultSummary(executionCoverageReport, coverageSheet, rowPos, TSColPos);
		if(WantToExecute.equalsIgnoreCase("Yes")) { // this validation is application if want to execute this script or not.
			if((!(ExecutionResult.contains("Pass")))||(ExecutionResult==null)) {
				synchronized (method) {
					test=extent.startTest(method.getName());
					test.assignAuthor("ADV");
					test.assignCategory("ADV TestReport");
					setTest(test);//new 
				}
			}else {
				// if script is already pass then skip the script
				SkipMethod=true;
				throw new SkipException("Skipping this test method :" + method.getName());
			}
		}else {
			SkipMethod=true;
			throw new SkipException("Skipping this test method :" + method.getName());
		}
		Reporter.log("***********************beforeMethod end**********************************",true);
	}
	@AfterClass(alwaysRun=true)
	public void afterClass(){
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  After Class start ************************",true);
		if(driver!=null){
			driver.close();
		}
		Reporter.log("****************After Class End*****************************************",true);
	}

	@AfterMethod(alwaysRun=true)
	public void closeMenu(ITestResult result, Method m,ITestContext testContext) throws BiffException, IOException {
		Reporter.log("*****************  After Method  Start************************",true);
		String coverageSheet="SummaryReport";
		int rowPos= ex.getRowIndex(executionCoverageReport, coverageSheet, m.getName(),2);
		if(result.getStatus()== ITestResult.FAILURE){
			ex.UpdateTestCaseScenarioResultExcel(executionCoverageReport, coverageSheet ,rowPos, TSColPos, "Fail;"+result.getThrowable().getMessage());
		}else  if(result.getStatus()== ITestResult.SKIP){
			ex.UpdateTestCaseScenarioResultExcel(executionCoverageReport, coverageSheet ,rowPos, TSColPos, "Skip");
			test.log(LogStatus.SKIP, "Test Case Skipped is :"+result.getName());
			test.log(LogStatus.SKIP, "Test Case Skipped is :"+result.getThrowable().getMessage());
		}else  if(result.getStatus()== ITestResult.SUCCESS){
			ex.UpdateTestCaseScenarioResultExcel(executionCoverageReport, coverageSheet ,rowPos, TSColPos, "Pass");
		}else{
			System.out.println("Method not executed");
		}
		extent.endTest(test);
		Reporter.log("************************After Method  End*********************************",true);
		if(driver!=null){
			driver.quit();
		}
	}
	@AfterSuite(alwaysRun=true)
	public void closeBrowser() throws ParserConfigurationException, IOException, SAXException, InterruptedException {
		Reporter.log("*********************************************************",true);
		Reporter.log("*****************  After Suite Start ************************",true);
		extent.flush();
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				try
				{
					Thread.sleep(5000);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
				);
		
		Reporter.log("*********************************************************", true);
		File sourceLocation = new File(result_FolderName+"/ADVReport.html");
		File destinationLocation = new File(result_FolderNamePath+"/ADVReport.html");
		FileUtils.copyFile(sourceLocation, destinationLocation);
		Reporter.log("*****************  After Suite End ************************",true);
		System.out.println("driver ->> " + driver);
		if(driver!=null){
			driver.quit();
		}
	}

}
