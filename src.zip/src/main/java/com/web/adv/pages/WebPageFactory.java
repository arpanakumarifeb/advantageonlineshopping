package com.web.adv.pages;

import org.openqa.selenium.WebDriver;

public class WebPageFactory {

	/**
	 * @return the advLogin
	 */
	public ADVLoginPage getadvLogin() {
		return advLogin;
	}
	
	public static void setadvLogin(ADVLoginPage advLogin) {
		WebPageFactory.advLogin = advLogin;
	}
	private static ADVLoginPage advLogin=null;
	
	
	public WebPageFactory(WebDriver driver) {
		instance(driver);
	}
	public static void instance(WebDriver driver){ 
			advLogin = new ADVLoginPage(driver);
			productCheckoutPage=new ProductCheckoutPage(driver);
	}
	
	public ProductCheckoutPage getNCInfoPage() {
		return productCheckoutPage;
	}
	
	public static void setProductCheckoutPage(ProductCheckoutPage productCheckoutPage) {
		WebPageFactory.productCheckoutPage = productCheckoutPage;
	}
	private static ProductCheckoutPage productCheckoutPage=null;

	

	
}