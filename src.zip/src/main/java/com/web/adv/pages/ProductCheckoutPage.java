package com.web.adv.pages;

import java.io.File;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import com.adv.common.Common;
import com.adv.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class ProductCheckoutPage {

	@FindBy(xpath =".//span[@id='speakersTxt']")
	private WebElement speakerProduct;

	@FindBy(xpath =".//h3[@class='categoryTitle roboto-regular sticky ng-binding']")
	private WebElement spearkerPageHeader;

	@FindBy(xpath = ".//a[@class='productName ng-binding']")        
	private List <WebElement> productList;
	
	@FindBy(xpath = ".//a[@class='productPrice ng-binding']")        
	private List <WebElement> productPriceList;
	
	@FindBy(xpath = ".//div[@id='Description']/h2[@class='roboto-thin screen768 ng-binding']")
	private  WebElement productPriceDetailPage;
	
	@FindBy(xpath = ".//h1[@class='roboto-regular screen768 ng-binding']")
	private WebElement productDetailsPage;

	@FindBy(xpath = ".//button[@name='save_to_cart']")
	private WebElement saveToCart;

	@FindBy(xpath = ".//a[@id='shoppingCartLink']//span[@class='cart ng-binding']")
	private WebElement shoppingCartVal;

	//SHOPPING CART Page
	
	@FindBy(xpath = ".//a[@id='shoppingCartLink']")
	private WebElement shoppingCartLink;
	
	@FindBy(xpath = ".//h3[@class='roboto-regular center sticky fixedImportant ng-binding']")
	private WebElement shoppingCartPage;
	
	@FindBy(xpath = ".//td[@class='smollCell quantityMobile']//label[@class='ng-binding']")
	private WebElement shoppingCartPageProductQty;
	
	@FindBy(xpath = ".//label[@class='roboto-regular productName ng-binding']")
	private WebElement shoppingCartPageProductName;
	
	@FindBy(xpath = ".//div[@id='shoppingCart']//button[@role='button']")
	private WebElement checkoutLink;

	//
	

	// payment Page
	@FindBy(xpath = ".//h3[@translate='ORDER_PAYMENT']")
	private  WebElement orderPaymentPage	;

	@FindBy(xpath = ".//h5[@translate='ORDER_SUMMARY']")
	private  WebElement orderSummary	;

	@FindBy(xpath =".//span[@class='itemsCount roboto-medium ng-binding']")
	private WebElement orderQty;
	
	
	@FindBy(xpath =".//tool-tip-cart[@id='toolTipCart'][not(@style)]//p[@class='price roboto-regular ng-binding']")
	private WebElement orderSummaryPrice;

	@FindBy(xpath =".//span[@class='roboto-medium totalValue ng-binding']")
	private WebElement totalPrice;
	

	private WebDriver driver;
	private Common common;

	public ProductCheckoutPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}


	/**
	 * Method To validate spearker product
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int ValidateSpearkerproduct(String ScreenshotRequire) throws InterruptedException{
		int productSize=0;
		try{
			common.waitForElementToBeDisplayed(speakerProduct, IConstants.LOW_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - speaker product loaded"+ common.captureScreenshot(ScreenshotRequire));
			common.clickOnObject(speakerProduct, "speakerProduct");	
			common.waitForElementLoaded(spearkerPageHeader, IConstants.LOW_WAIT_TIME);
			Assert.assertEquals("SPEAKERS", spearkerPageHeader.getText().trim(),"spearker Page header is not appearing correctly");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - speaker product Page loaded"+ common.captureScreenshot(ScreenshotRequire));
			productSize= productList.size();
			if(productSize>0) {
				WebTestCase.getTest().log(LogStatus.INFO, "Product list is apeparing, size:: " + productSize);
			}else {
				WebTestCase.getTest().log(LogStatus.INFO, "Product list is not apeparing, size:: " + productSize);
			}
			
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}catch(Exception exp2){
			System.out.println("Got Exception Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return productSize;
	}
	
	
	/**
	 * Method To AddtoCart process
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public int ValidateAddToCartProcess(String ScreenshotRequire) throws InterruptedException{
		int productSize=0;
		String ProductPrice=null;
		String productName=null;
		try{
			productSize= productList.size();
			if(productSize>0) {
				common.waitForElementToBeDisplayed(productList.get(0), IConstants.LOW_WAIT_TIME);
				productName=productList.get(0).getText().trim().toLowerCase();
				ProductPrice=productPriceList.get(0).getText().trim(); // product price in product list page
				
				// click on first product from list
				common.clickOnObject(productList.get(0), "firstProduct"); 
				common.waitForElementLoaded(productDetailsPage, IConstants.LOW_WAIT_TIME);
				Assert.assertEquals(productName.toLowerCase(), productDetailsPage.getText().toLowerCase(),"Product Name is not apeparing correct in product details page");
				WebTestCase.getTest().log(LogStatus.PASS, "Selected Product name " + productDetailsPage.getText());
				
				Assert.assertEquals(ProductPrice, productPriceDetailPage.getText().trim(),"Product price is not apeparing correct in product details page");
				WebTestCase.getTest().log(LogStatus.PASS, "Product Price " + productPriceDetailPage.getText());
				
				// addToCart
				
				common.isElementDisplayed(driver, saveToCart, IConstants.LOW_WAIT_TIME);
				common.clickOnObject(saveToCart, "saveToCart");
				
				// verify the shopping cart value after add to cart
				common.waitForElementToBeDisplayed(shoppingCartVal, IConstants.LOW_WAIT_TIME);
 				int addToCartList= Integer.parseInt(shoppingCartVal.getText());
				Assert.assertTrue(addToCartList>0,"Product not added to the cart correctly");
				
				common.waitForElementToBeDisplayed(shoppingCartLink, IConstants.LOW_WAIT_TIME);
				common.clickOnObject(shoppingCartLink, "shoppingCartLink");
				
				// navigate to Shopping cart page
				common.waitForElementLoaded(shoppingCartPage, IConstants.LOW_WAIT_TIME);
				Assert.assertTrue(shoppingCartPage.getText().trim().contains("SHOPPING CART"),"ORDER PAYMENT page not loaded correctly");
				
				int shoppingCartPQty= Integer.parseInt(shoppingCartPageProductQty.getText().trim());
				if(shoppingCartPQty>0) { // checking the product qty
					WebTestCase.getTest().log(LogStatus.PASS, "Product qty is apearing correctly in shopping cart page " + shoppingCartPQty + common.captureScreenshot("true"));
					Assert.assertEquals(productName.toLowerCase(), shoppingCartPageProductName.getText().trim().toLowerCase(),"Product Name is not apeparing correctly in shopping cart page!!");
				}else {
					WebTestCase.getTest().log(LogStatus.FAIL, "Product qty is not apearing correctly in shopping cart page " + shoppingCartPQty + common.captureScreenshot("true"));
					
				}
				
				common.waitForElementToBeDisplayed(checkoutLink, IConstants.LOW_WAIT_TIME);
				common.clickOnObject(checkoutLink, "checkoutLink");
				
				// order payment page
				common.waitForElementLoaded(orderPaymentPage, IConstants.LOW_WAIT_TIME);
				Assert.assertEquals("ORDER PAYMENT", orderPaymentPage.getText().trim(),"ORDER PAYMENT page not loaded correctly");
				
				// order summary details
				
				common.waitForElementLoaded(orderSummary, IConstants.LOW_WAIT_TIME);
				Assert.assertEquals("ORDER SUMMARY", orderSummary.getText().trim(),"ORDER SUMMARY details not loaded correctly");
				// verify order name
				
				WebTestCase.getTest().log(LogStatus.PASS, "Product Name::  " + productName);
				
				// verify order price
				String [] splits=null;
				String orderQ=null;
				if(orderQty.getText().trim().contains("ITEM")) {
					splits = orderQty.getText().trim().split("ITEM");
					orderQ=splits[0].trim();
				}
				System.out.println("orderQ:: " + orderQ);
				Assert.assertEquals(1, Integer.parseInt(orderQ),"Product qty is not apeparing correct in product summary page");
				WebTestCase.getTest().log(LogStatus.PASS, "Product qty " + Integer.parseInt(orderQ));
				
				Assert.assertEquals(ProductPrice, orderSummaryPrice.getText().trim(),"Product price is not apeparing correct in product summary page");
				WebTestCase.getTest().log(LogStatus.PASS, "Product Price " + orderSummaryPrice.getText());
				
				Assert.assertEquals(ProductPrice, totalPrice.getText().trim(),"Total price is not apeparing correct in product summary page");
				WebTestCase.getTest().log(LogStatus.PASS, "Total Product Price is appearing correctly " + totalPrice.getText());
				
				
			}else {
				WebTestCase.getTest().log(LogStatus.INFO, "Product list is not apeparing, size:: " + productSize);
			}
			
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}catch(Exception exp2){
			System.out.println("Got Exception Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return productSize;
	}

	

	/**
	 * Method To get Last downloaded file name
	 * @author Chinmay
	 * @throws InterruptedException 
	 */
	public File getLatestFilefromDir(String dirPath){
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        return null;
	    }
	
	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    return lastModifiedFile;
	}
}
