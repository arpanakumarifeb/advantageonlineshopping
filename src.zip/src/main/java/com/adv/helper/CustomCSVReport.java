package com.adv.helper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

public class CustomCSVReport {
	public static String result_FolderName = null;
	public static BufferedWriter out = null;
	public static BufferedWriter outSummary = null;
	public static String result_FolderNamePath = System.getProperty("user.dir") + "/Reports/";
	public static String csvFile = System.getProperty("user.dir") + "\\report.csv";
	public static String SAMPLE_CSV_FILE = System.getProperty("user.dir") + "\\Jmeter_Report.csv";
	public static BufferedReader br = null;
	public static String line = "";
	public static String cvsSplitBy = ",";
	static StringBuffer moduleresult = null;
	static BufferedWriter writer = null;
	static CSVPrinter csvPrinter = null;

	static {
		try {
			Date d = new Date();
			String date = d.toString().replaceAll(" ", "_");
			date = date.replaceAll(":", "_");
			date = date.replaceAll("\\+", "_");
			result_FolderName = result_FolderNamePath + date.substring(0, 10) + "/ENTIRE_TEST_REPORT" + "_" + date;
			new File(result_FolderName).mkdirs();
			String indexHtmlPath = result_FolderName + "/Jmeter.html";
			new File(indexHtmlPath).createNewFile();
			FileWriter fstream = new FileWriter(indexHtmlPath);
			out = new BufferedWriter(fstream);
			writer = Files.newBufferedWriter(Paths.get(SAMPLE_CSV_FILE));
			csvPrinter = new CSVPrinter(writer,
					CSVFormat.DEFAULT.withHeader("TimeStamp", "Elapsed", "URL", "Response Code", "ResponseMessage",
							"ThreadName", "DataType", "Success", "FailureMsg", "bytes", "sentBytes", "grpThreads",
							"allThreads", "Latency", "IdleTime", "Connect"));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {
		generateHeaderReport();
		readCSVData();
	}

	public void callJmeterReport() throws IOException {
		generateHeaderReport();
		readCSVData();
	}

	private static void readCSVData() throws IOException {
		try {

			br = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/report.csv"));
			while ((line = br.readLine()) != null) {

				// use comma as separator

				String[] value = line.split(cvsSplitBy);
				if (!value[0].equals("timeStamp")) {
					generateHeaderReportJmeter(value[0], value[1], value[2], value[3], value[4], value[5], value[6],
							value[7], value[8]);
					generateCustomCSVReport(getTime(value[0]), value[1], value[2], value[3], value[4], value[5],
							value[6], value[7], value[8], value[9], value[10], value[11], value[12], value[13],
							value[14], value[15]);
				}
			}
			generateFooterReport();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			csvPrinter.flush();
			if (br != null) {
				try {
					br.close();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static void generateCustomCSVReport(String string, String string2, String string3, String string4,
			String string5, String string6, String string7, String string8, String string9, String string10,
			String string11, String string12, String string13, String string14, String string15, String string16)
			throws IOException {
		try {
			csvPrinter.printRecord(string, string2, string3, string4, string5, string6, string7, string8, string9,
					string10, string11, string12, string13, string14, string15, string16);
		} catch (Exception e) {
		}
	}

	public static String getTime(String path) {
		String res = path.substring(0, path.length() - 3);
		System.out.println(res);
		long unixSeconds = Long.parseLong(res);
		Date date = new Date(unixSeconds * 1000L); // *1000 is to convert
													// seconds to milliseconds
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // the
																			// format
																			// of
																			// your
																			// date
		sdf.setTimeZone(TimeZone.getTimeZone("GMT+5:30")); // give a timezone
															// reference for
															// formating (see
															// comment at the
															// bottom
		String formattedDate = sdf.format(date);
		System.out.println(formattedDate);
		return formattedDate.toString();
	}

	public static void generateFooterReport() {
		try {

			moduleresult = new StringBuffer();
			moduleresult.append("</table>");
			moduleresult.append("</html>");
			out.write(moduleresult.toString());
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void generateHeaderReportJmeter(String date, String code, String reqName, String servName,
			String ThrGrpCount, String text, String status, String looping, String a) throws IOException {
		moduleresult = new StringBuffer();
		moduleresult.append(
				"<tr WIDTH=100%><td width=15.4% align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(getTime(date)
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(code
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(reqName
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(servName
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(ThrGrpCount
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(text
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(status
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(looping
				+ "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				a + "</b></td><td width=100 align=left bgcolor=#D2D4D4><FONT COLOR=black FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append("</b></td></tr>");
		out.write(moduleresult.toString());
	}

	public static void generateHeaderReport() throws IOException {
		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		moduleresult = new StringBuffer();
		moduleresult.append(
				"<html><HEAD></HEAD><Title>Automation Results</Title><body background: #0e0e0e;><p><b>Load Test Results</b></p><p>Date Report:");

		moduleresult.append(d.toString());
		moduleresult.append(
				"</p><hr><table   border=1 cellspacing=1 cellpadding=3 width=100%><tr WIDTH=100%><td width=15.4% align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"TimeStamp:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"elapsed:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"Label:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"ResponseCode:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"responseMessage:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"ThreadName:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"dataType:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append(
				"success:</b></td><td width=100 align=left bgcolor=#05558A><FONT COLOR=white FACE=VERDANA SIZE=2.75><b>");
		moduleresult.append("Connect:</b></td></tr>");
		out.write(moduleresult.toString());
	}
}