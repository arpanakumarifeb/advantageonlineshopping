package com.adv.common;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.*;
import org.testng.*;

import com.adv.common.Common;
import com.adv.helper.IConstants;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.google.common.base.*;
import com.web.adv.pages.WebTestCase;

import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;

/**
 * This class contains all the common methods for common selenium events which
 * can be reused through out the project.
 * 
 */

@SuppressWarnings({ "unused" })
public class Common extends WebTestCase {

	private static boolean initialized = true;
	private static WebDriver driver;// = selenium.getDriver();
	private Logger logger = Logger.getLogger(Common.class.getName());
	private static final long SLEEP_SWITCH = 30000l;
	private static final long SLEEP_THREAD_SLEEP = 250;

	Robot robot = null;
	public Common(WebDriver driver2) {
		driver = driver2;
		try {
			robot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	public String geturl(String Env) {
		return Env;
	}

	

	/**
	 * This method id used to clicking on object
	 * 
	 * @param e
	 * @param objectname
	 * @return
	 */
	public boolean clickOnObject(WebElement e, String objectname) {
		String object= e.getText();
		try {
			//String s;
			if (e == null) {
				System.out.println(objectname + "does not exist on webpage");
				Reporter.log(objectname + "does not exist on webpage");
				return false;
			}

		} catch (Exception exception) {

		}
		// handleUnexpectedDialog(3);
		boolean isClickDone = false;
		try {
			e = waitForElementToBeDisplayed(e, 40);
			if (isElementPresent(e)) {
				if (e != null) {
					e.click();
					System.out.println("clicked on object" + object);
				}
			}
		} catch (Exception exception3) {
			e.click();
			System.out.println("clicked on " + e.getText());
			Reporter.log("Some Exception happened ");
		}
		/*if (isClickDone == false) {
			return false;
		}*/
		Reporter.log("Clicked the " + objectname);
		return true;
	}

	

	/**
	 * This method is used to set the object value
	 * 
	 * @param e
	 * @param objectname
	 * @param objValue
	 * @return
	 */
	public boolean setObjectValue(WebElement e, String objectname, String objValue) {
		boolean isSetDone = false;
		try {
			e = waitForElementToBeDisplayed(e, 40);
			if (e != null) {
				e.clear();
				e.sendKeys(objValue);

				System.out.println("Enter in text box:::" + objValue);
				isSetDone = true;
			}
		} catch (Exception exception3) {
			Reporter.log("Some Exception happened ");
		}
		if (isSetDone == false) {
			return false;
		}
		Reporter.log(objectname + " Value is set to :-" + objValue);
		return true;
	}

	
	

	/**
	 * isElementPresent(WebElement e) Method to validate a particular webelement
	 * is available on webpage or not
	 */
	public boolean isElementPresent(WebElement e) {
		try {
			if (e == null) {
				Reporter.log("Control does not exist on page", true);
				return false;
			}
			//handleUnexpectedDialog(1);

			if (e.isEnabled() == false) {
				Reporter.log("Element not displayed", true);
				return false;
			}
		} catch (NoSuchElementException nsee) {
			Reporter.log(e.toString() + " is not available");
			return false;
		}
		Reporter.log("Information ::::Element "+e.getText()+" is available for further actions", true);
		return true;
	}


	

	/**
	 * This method is used to verify wait for page load.
	 * 
	 * @param driver
	 * @return boolean value
	 */
	public boolean waitForPageLoad(WebDriver driver) {

		long startTime = System.currentTimeMillis();
		long waitTime = 120000;
		String pageLoadStatus = null;
		try {
			do {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				pageLoadStatus = (String) js.executeScript("return document.readyState");
				System.out.print((System.currentTimeMillis() - startTime));

				if ((System.currentTimeMillis() - startTime) > waitTime) {

					Reporter.log("timeout completed " + waitTime + "ms");

					return false;
				}
				System.out.println("waiting for page load");
				Thread.sleep(100);
			} while (!pageLoadStatus.equals("complete"));
			System.out.println("Page Loaded correctly");

		} catch (Exception e) {
			System.out.println("some Exeption happened during page load:::::" + e.toString());
		}
		return true;
	}

	

	/**
	 * This method is used to wait for web element to be displayed in given time
	 * 
	 * @param element
	 * @param timeInSeconds
	 * @return WebElement
	 */
	public WebElement waitForElementToBeDisplayed(WebElement element, int timeInSeconds) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeInSeconds);
			element = wait.until(ExpectedConditions.elementToBeClickable(element));
			if (element != null && element.isDisplayed()) {

				return element;
			} else {
				return null;
			}
		} catch (NoSuchElementException e) {
			Reporter.log("FAIL" + "--No Such Element Exception--", true);
			e.printStackTrace();
			return null;

		} catch (StaleElementReferenceException e) {
			Reporter.log("FAIL" + "--Stale Element Exception--", true);
			e.printStackTrace();
			return null;
		} catch (TimeoutException toe) {
			Reporter.log("FAIL" + "--Time Out Exception--", true);
			toe.printStackTrace();
			return null;
		}
	}

	/**
	 * This method is used to wait for web element to be visible in given time
	 * 
	 * @param element
	 * @param timeInSeconds
	 * @return WebElement
	 */
	public WebElement waitForElementLoaded(WebElement element, int timeInSeconds) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeInSeconds);
			element = wait.until(ExpectedConditions.visibilityOf(element));
			if (element != null && element.isDisplayed()) {

				return element;
			} else {
				return null;
			}
		} catch (NoSuchElementException e) {
			Reporter.log("FAIL" + "--No Such Element Exception--", true);
			e.printStackTrace();
			return null;

		} catch (StaleElementReferenceException e) {
			Reporter.log("FAIL" + "--Stale Element Exception--", true);
			e.printStackTrace();
			return null;
		} catch (TimeoutException toe) {
			Reporter.log("FAIL" + "--Time Out Exception--", true);
			toe.printStackTrace();
			return null;
		}
	}

	
	public String captureScreenshot(String screenshotFlag) {
		String val=null;
		if(screenshotFlag.contains("true"))
		{
			Date d = new Date();
			String date = d.toString().replaceAll(" ", "_");
			date = date.replaceAll(":", "_");
			date = date.replaceAll("\\+", "_");
			System.getProperty("line.separator");

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File reportPath = new File(result_FolderName);
			if (!reportPath.exists()) {
				if (!reportPath.mkdirs()) {
					throw new RuntimeException("Failed to create screenshot directory");
				}
			}

			
			String xx= getTime()+ "_screenshot.png";
			String f = result_FolderName + "/" + xx;
			File dest = new File(f);
			try {
				FileUtils.copyFile(scrFile, dest);
			} catch (IOException e) {
				e.printStackTrace();
			}
			StringBuilder href = new StringBuilder();
			val = href
					.append("<div><a HREF='" + xx + "'><img src='" + xx
							+ "' alt='Screen Shot' style='width:250px;height:200px'>Link to Screeshot</a></div>")
					.toString();
		}else {
			val=".";
		}
		return val;
	}

	public String getExecutionTime() {

		Date d = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("MMM_dd_HH_mm_ss");
		//System.out.println("Current Date: " + ft.format(d));
		return ft.format(d);

	}

	public String getTime() {

		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		//System.out.println(date.toString());

		return date.toString();

	}

	
	public static WebElement isElementDisplayed(WebDriver driver,WebElement ele,int time)
	{
		for(int i=0;i<time;i++)
		{
			try{
				Thread.sleep(1000);
				ele.isDisplayed();
				break;
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(1000);
					ele.isDisplayed();
					break;
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear on DOM");
				}
			}


		}
		return ele;

	}

	
	public static WebElement isElementDisplayed(By by,int time)
	{
		WebElement ele = null;
		for(int i=0;i<time;i++)
		{
			try{
				ele = driver.findElement(by);
				break;
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(1000);
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear on DOM");
				}
			}

		}
		return ele;

	}

	public static int generateRandomIntIntRange(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	
}