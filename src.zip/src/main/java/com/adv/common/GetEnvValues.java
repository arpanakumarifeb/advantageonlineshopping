package com.adv.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GetEnvValues {
	
	InputStream in;
	private String FILEPATH = "env.properties";
	Properties envDetails = new Properties();
	
	public GetEnvValues() throws IOException
 {
		try {
			if (in == null) {
				in = new FileInputStream(System.getProperty("user.dir") + "\\environment\\" +"env.properties");
				envDetails.load(in);
				System.out.println("Read the Env values Successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			if(in!= null)
			{
			in.close();
			}
			
		}
	}
	
	public String envKeyValue(String key)
	{
		return envDetails.getProperty(key);
	}
	
	
	
}
