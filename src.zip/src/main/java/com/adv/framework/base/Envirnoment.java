package com.adv.framework.base;

public class Envirnoment
{
  private String url;
  private String userName;
  private String password;
  private String browser;
  private boolean isLocal = true;
  private String channel;
  private String gridURL;
  private boolean isTestdroid = false;
  private String testdroiduser;
  private String testdroidpass;
  private String testdroidproj;
  private String locale;
  private String env;
  private String deviceType = "mobile";
  private String fboauthToken;
  private String twittertoken;
  private String twitterSecretToken;
  private String twitterConsumerkey;
  private String twitterConsumerSecretKey;

  public String getTwittertoken()
  {
    return this.twittertoken;
  }
  public void setTwittertoken(String twittertoken) {
    this.twittertoken = twittertoken;
  }
  public String getTwitterSecretToken() {
    return this.twitterSecretToken;
  }
  public void setTwitterSecretToken(String twitterSecretToken) {
    this.twitterSecretToken = twitterSecretToken;
  }
  public String getTwitterConsumerkey() {
    return this.twitterConsumerkey;
  }
  public void setTwitterConsumerkey(String twitterConsumerkey) {
    this.twitterConsumerkey = twitterConsumerkey;
  }
  public String getTwitterConsumerSecretKey() {
    return this.twitterConsumerSecretKey;
  }
  public void setTwitterConsumerSecretKey(String twitterConsumerSecretKey) {
    this.twitterConsumerSecretKey = twitterConsumerSecretKey;
  }

  public String getTestdroiduser()
  {
    return this.testdroiduser;
  }
  public void setTestdroiduser(String testdroiduser) {
    this.testdroiduser = testdroiduser;
  }
  public String getTestdroidpass() {
    return this.testdroidpass;
  }
  public void setTestdroidpass(String testdroidpass) {
    this.testdroidpass = testdroidpass;
  }
  public String getTestdroidproj() {
    return this.testdroidproj;
  }
  public void setTestdroidproj(String testdroidproj) {
    this.testdroidproj = testdroidproj;
  }
  public String getGridURL() {
    return this.gridURL;
  }
  public void setGridURL(String gridURL) {
    this.gridURL = gridURL;
  }
  public String getChannel() {
    return this.channel;
  }
  public void setChannel(String channel) {
    this.channel = channel;
  }
  public String getUrl() {
    return this.url;
  }
  public void setUrl(String url) {
    this.url = url;
  }
  public String getUserName() {
    return this.userName;
  }
  public void setUserName(String userName) {
    this.userName = userName;
  }
  public String getPassword() {
    return this.password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public String getBrowser() {
    return this.browser;
  }
  public void setBrowser(String browser) {
    this.browser = browser;
  }
  public boolean isLocal() {
    return this.isLocal;
  }
  public void setLocal(boolean isLocal) {
    this.isLocal = isLocal;
  }
  public boolean isTestdroid() {
    return this.isTestdroid;
  }
  public void setTestdroid(boolean isTestdroid) {
    this.isTestdroid = isTestdroid;
  }
  public String getLocale() {
    return this.locale;
  }
  public void setLocale(String locale) {
    this.locale = locale;
  }
  public String getEnv() {
    return this.env;
  }
  public void setEnv(String env) {
    this.env = env;
  }
  public String getDeviceType() {
    return this.deviceType;
  }
  public void setDeviceType(String deviceType) {
    this.deviceType = deviceType;
  }
  public String getFboauthToken() {
    return this.fboauthToken;
  }
  public void setFboauthToken(String fboauthToken) {
    this.fboauthToken = fboauthToken;
  }
}