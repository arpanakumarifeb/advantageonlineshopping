package com.adv.framework.base;
import java.io.File;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;

public class SeleniumDriverUtil
{
  private static String URL;
   private WebDriver driver;

  public WebDriver getDriver()
  {
    String browser = "chrome";
     if (browser.equalsIgnoreCase("chrome")) {
        if (this.driver == null)
        {
          String FILEPATH = System.getProperty("user.dir") + "/" + "src/main/resources/exe/windowsdriver/chromedriver.exe";
          File file = new File(FILEPATH);
          System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
          
        }
     }
     return this.driver = new ChromeDriver();	
  }
  public static String getLoginURL() {
    Reporter.log("URL is:" + URL, true);
    return URL;
  }

  
}